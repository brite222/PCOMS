﻿namespace PCOMS.Application.DTOs
{
    public class ProjectDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = default!;
        public string Status { get; set; } = default!;
        public string ClientName { get; set; } = default!;
        public string? ManagerName { get; set; } 
    }
}

