﻿namespace PCOMS.Application.DTOs
{
    public class DeveloperDashboardDto
    {
        public decimal TotalHours { get; set; }
        public decimal PendingHours { get; set; }
        public decimal ApprovedHours { get; set; }
    }
}
