﻿namespace PCOMS.Models
{
    public enum TimeEntryStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
